/*
 * Onur.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Onur".
 *
 * Model version              : 1.8
 * Simulink Coder version : 9.5 (R2021a) 14-Nov-2020
 * C source code generated on : Fri Jan 21 14:07:12 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Onur_h_
#define RTW_HEADER_Onur_h_
#include <stddef.h>
#include <float.h>
#include <string.h>
#ifndef Onur_COMMON_INCLUDES_
#define Onur_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rt_logging.h"
#endif                                 /* Onur_COMMON_INCLUDES_ */

#include "Onur_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_nonfinite.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
#define rtmGetContStateDisabled(rtm)   ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
#define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
#define rtmGetContStates(rtm)          ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
#define rtmSetContStates(rtm, val)     ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
#define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
#define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
#define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetFinalTime
#define rtmGetFinalTime(rtm)           ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetIntgData
#define rtmGetIntgData(rtm)            ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
#define rtmSetIntgData(rtm, val)       ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
#define rtmGetOdeF(rtm)                ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
#define rtmSetOdeF(rtm, val)           ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
#define rtmGetOdeY(rtm)                ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
#define rtmSetOdeY(rtm, val)           ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
#define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
#define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
#define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
#define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetRTWLogInfo
#define rtmGetRTWLogInfo(rtm)          ((rtm)->rtwLogInfo)
#endif

#ifndef rtmGetZCCacheNeedsReset
#define rtmGetZCCacheNeedsReset(rtm)   ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
#define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
#define rtmGetdX(rtm)                  ((rtm)->derivs)
#endif

#ifndef rtmSetdX
#define rtmSetdX(rtm, val)             ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTFinal
#define rtmGetTFinal(rtm)              ((rtm)->Timing.tFinal)
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Switch1;                      /* '<S2>/Switch1' */
  real_T Switch;                       /* '<S2>/Switch' */
  real_T FilterCoefficient;            /* '<S38>/Filter Coefficient' */
} B_Onur_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  struct {
    void *LoggedData[2];
  } Motors_before_FI_PWORK;            /* '<S1>/Motors_before_FI' */
} DW_Onur_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Filter_CSTATE;                /* '<S30>/Filter' */
  real_T Integrator_CSTATE;            /* '<S35>/Integrator' */
} X_Onur_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Filter_CSTATE;                /* '<S30>/Filter' */
  real_T Integrator_CSTATE;            /* '<S35>/Integrator' */
} XDot_Onur_T;

/* State disabled  */
typedef struct {
  boolean_T Filter_CSTATE;             /* '<S30>/Filter' */
  boolean_T Integrator_CSTATE;         /* '<S35>/Integrator' */
} XDis_Onur_T;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T Sum;                    /* '<S2>/Sum' */
  const real_T DerivativeGain;         /* '<S29>/Derivative Gain' */
  const real_T IntegralGain;           /* '<S32>/Integral Gain' */
} ConstB_Onur_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* Real-time Model Data Structure */
struct tag_RTM_Onur_T {
  const char_T *errorStatus;
  RTWLogInfo *rtwLogInfo;
  RTWSolverInfo solverInfo;
  X_Onur_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[2];
  real_T odeF[3][2];
  ODE3_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T tFinal;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block signals (default storage) */
extern B_Onur_T Onur_B;

/* Continuous states (default storage) */
extern X_Onur_T Onur_X;

/* Block states (default storage) */
extern DW_Onur_T Onur_DW;
extern const ConstB_Onur_T Onur_ConstB;/* constant block i/o */

/* Model entry point functions */
extern void Onur_initialize(void);
extern void Onur_step(void);
extern void Onur_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Onur_T *const Onur_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Constant2' : Unused code path elimination
 * Block '<S40>/Proportional Gain' : Unused code path elimination
 * Block '<S42>/Saturation' : Unused code path elimination
 * Block '<S44>/Sum' : Unused code path elimination
 * Block '<S2>/Speed' : Unused code path elimination
 * Block '<S2>/Sum1' : Unused code path elimination
 * Block '<S2>/Sum2' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Onur'
 * '<S1>'   : 'Onur/Subsystem'
 * '<S2>'   : 'Onur/Subsystem/LineFollowControl'
 * '<S3>'   : 'Onur/Subsystem/LineFollowControl/PID Controller'
 * '<S4>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/Anti-windup'
 * '<S5>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/D Gain'
 * '<S6>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/Filter'
 * '<S7>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/Filter ICs'
 * '<S8>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/I Gain'
 * '<S9>'   : 'Onur/Subsystem/LineFollowControl/PID Controller/Ideal P Gain'
 * '<S10>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Ideal P Gain Fdbk'
 * '<S11>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Integrator'
 * '<S12>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Integrator ICs'
 * '<S13>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/N Copy'
 * '<S14>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/N Gain'
 * '<S15>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/P Copy'
 * '<S16>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Parallel P Gain'
 * '<S17>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Reset Signal'
 * '<S18>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Saturation'
 * '<S19>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Saturation Fdbk'
 * '<S20>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Sum'
 * '<S21>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Sum Fdbk'
 * '<S22>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tracking Mode'
 * '<S23>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tracking Mode Sum'
 * '<S24>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tsamp - Integral'
 * '<S25>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tsamp - Ngain'
 * '<S26>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/postSat Signal'
 * '<S27>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/preSat Signal'
 * '<S28>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Anti-windup/Passthrough'
 * '<S29>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/D Gain/Internal Parameters'
 * '<S30>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Filter/Cont. Filter'
 * '<S31>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Filter ICs/Internal IC - Filter'
 * '<S32>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/I Gain/Internal Parameters'
 * '<S33>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Ideal P Gain/Passthrough'
 * '<S34>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Ideal P Gain Fdbk/Disabled'
 * '<S35>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Integrator/Continuous'
 * '<S36>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Integrator ICs/Internal IC'
 * '<S37>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/N Copy/Disabled'
 * '<S38>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/N Gain/Internal Parameters'
 * '<S39>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/P Copy/Disabled'
 * '<S40>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Parallel P Gain/Internal Parameters'
 * '<S41>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Reset Signal/Disabled'
 * '<S42>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Saturation/Enabled'
 * '<S43>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Saturation Fdbk/Disabled'
 * '<S44>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Sum/Sum_PID'
 * '<S45>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Sum Fdbk/Disabled'
 * '<S46>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tracking Mode/Disabled'
 * '<S47>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tracking Mode Sum/Passthrough'
 * '<S48>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tsamp - Integral/Passthrough'
 * '<S49>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/Tsamp - Ngain/Passthrough'
 * '<S50>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/postSat Signal/Forward_Path'
 * '<S51>'  : 'Onur/Subsystem/LineFollowControl/PID Controller/preSat Signal/Forward_Path'
 */
#endif                                 /* RTW_HEADER_Onur_h_ */
